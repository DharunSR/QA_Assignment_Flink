package com.weather_shopper.Runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)

@CucumberOptions(features = "src/test/features/QA_Assignment_Flink.feature",
        glue = "com/weather_shopper/StepDefinition",
        monochrome = true,
        strict = true,
//        format = { "pretty","html: cucumber-html-reports",
//                "json: cucumber-html-reports/cucumber.json" },
        dryRun = false)
public class Runner {
//

}
