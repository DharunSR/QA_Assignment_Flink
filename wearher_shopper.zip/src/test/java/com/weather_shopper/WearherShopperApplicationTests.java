package com.weather_shopper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WearherShopperApplicationTests {

	@Test
	void contextLoads() {
	}

}
