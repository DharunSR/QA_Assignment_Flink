package com.weather_shopper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WearherShopperApplication {

	public static void main(String[] args) {
		SpringApplication.run(WearherShopperApplication.class, args);
	}

}
