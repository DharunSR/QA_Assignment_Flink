package com.weather_shopper.dataProvider;

import com.weather_shopper.annotations.PageObjects;
import lombok.Data;

@Data
@PageObjects
public class dataProvider {

    String currentTemperature;
    String productCategory;
    String product1;
    String product2;
    String email;
    String cardnumber;
    String validity;
    String cvv;
    String postcode;
}
