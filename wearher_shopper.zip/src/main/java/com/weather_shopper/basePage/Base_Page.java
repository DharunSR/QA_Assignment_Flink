package com.weather_shopper.basePage;

import com.weather_shopper.annotations.LazyAutowired;
import com.weather_shopper.annotations.PageObjects;
import com.weather_shopper.config.LocatorsPropertyFile;
import com.weather_shopper.config.PropertyFile;
import io.cucumber.java.bs.I;
import org.junit.After;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.context.ApplicationContext;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

@PageObjects
public class Base_Page {

    @LazyAutowired
    private WebDriver driver;

    @LazyAutowired
    private ApplicationContext applicationContext;

    @LazyAutowired
    private WebDriverWait webDriverWait;

    @LazyAutowired
    private JavascriptExecutor js;

    @LazyAutowired
    private PropertyFile propertyFile;

    @LazyAutowired
    private LocatorsPropertyFile locatorspropertyFile;

    @PostConstruct
    private void init() {
        PageFactory.initElements(driver, this);
        driver.manage().window().maximize();
    }

    public void load_page(String url) {
        if (!driver.getCurrentUrl().contains(url)) {
            driver.manage().deleteAllCookies();
            driver.get(url);
        }
    }

    public void enter_text(WebElement element, String text) {
        scroll_to_element(element);
        element.clear();
        element.sendKeys(text);
    }

    public void click_button(WebElement element) {
        scroll_to_element(element);
        element.click();
    }

    public void send_enter(WebElement element) {
        scroll_to_element(element);
        element.sendKeys(Keys.ENTER);
    }

    public void waitfor(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }

    public WebElement returnElement_id(String elementname) {
        return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id(elementname)));
    }

    public WebElement returnElement_name(String elementname) {
        return webDriverWait.until(ExpectedConditions.elementToBeClickable(By.name(elementname)));
    }

    public WebElement returnElement_css(String elementname) {
        return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(elementname)));
    }

    public WebElement returnElement_tag(String elementname) {
        return webDriverWait.until(ExpectedConditions.elementToBeClickable(By.tagName(elementname)));
    }

    public WebElement returnElement_class(String elementname) {
        return webDriverWait.until(ExpectedConditions.elementToBeClickable(By.className(elementname)));
    }

    public WebElement returnElement_xpath(String elementname) {
        return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(elementname)));
    }

    public String get_text(WebElement element) {
        wait_until_element_clickable(element);
        scroll_to_element(element);
        return element.getText();
    }

    public boolean wait_until_element_clickable(WebElement element) {
        boolean value = false;
        try {
            webDriverWait.until(ExpectedConditions.elementToBeClickable(element));
        } catch (NoSuchElementException e) {
            System.out.println("caught NoSuchElementException - " + element + " not found");
            value = true;
        } catch (TimeoutException e) {
            System.out.println("caught TimeoutException - " + element + " not found");
        }
        return value;
    }

    private void scroll_to_element(WebElement element) {
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }


    public void selectLeastExpensiveProduct(String product1, String product2){
        List<WebElement> elements = driver.findElements(By.xpath(locatorspropertyFile.getProductList_xpath()));
        ArrayList<Integer> list = new ArrayList<Integer>();
        List<WebElement> priceList = driver.findElements(By.xpath("//p[contains(text(),'Price')]"));
        List<WebElement> addButton = driver.findElements(By.xpath("//*[@class='btn btn-primary']"));
        int flag = 0; String product = product1;
        for (WebElement price:priceList) {
            String [] value = price.getText().split(" ");
            String index = String.valueOf(value.length-1);
            list.add(Integer.parseInt((value[Integer.parseInt(index)])));
        }
        Collections.sort(list);
        System.out.println("Price List is "+list);
        for (int i=0; i< list.size()-1; i++){
            for (WebElement button:addButton) {
                String textValue = button.getAttribute("onclick");
                String price = textValue.replaceAll("[^\\d]", " ").trim();
                if (price.contains(" ")){
                    String [] prices = price.split(" ");
                    price = prices[2];
                }

                if (list.get(i) == Integer.parseInt(price)){
                    if (textValue.toLowerCase(Locale.ROOT).contains(product.toLowerCase(Locale.ROOT))){
                        button.click();
                        flag ++;
                        product = product2;
                        i=0;
                        break;
                    }
                }
            }
            if (flag==2){
                break;
            }
        }
    }

    public void returnFrames(){
        List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
        int size = iframes.size();
//        driver.switchTo().;
        System.out.println("Size of frame is "+size);
    }
    @After
    public void quitDriver() {
        System.out.println("Before quitting in quit class");
        applicationContext.getBean(WebDriver.class).quit();
        System.out.println("After quitting driver");
    }

}
