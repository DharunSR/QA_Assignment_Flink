package com.weather_shopper.config;

import com.weather_shopper.annotations.PageObjects;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;

@Data
@PageObjects
@PropertySource("classpath:application.properties")
//@PropertySource("classpath:application-dev.properties")
public class PropertyFile {

    @Value("${chromedriverpath}")
    private String chromedriverpath;

    @Value("${firefoxdriverpath}")
    private String firefoxdriverpath;

    @Value("${iedriverpath}")
    private String iedriverpath;

    @Value("${Timeout}")
    private int Timeout;

    @Value("${url}")
    private String url;

}
