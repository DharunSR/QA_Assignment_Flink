package com.weather_shopper.config;

import com.weather_shopper.annotations.BeanScope;
import com.weather_shopper.annotations.LazyAutowired;
import com.weather_shopper.annotations.LazyConfiguration;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

@LazyConfiguration
public class driverConfig {

    @LazyAutowired
    private PropertyFile propertyFile;


    @BeanScope
    @ConditionalOnProperty(name = "browser", havingValue = "chrome")
    public WebDriver chromeWebDriver() {
        System.setProperty("webdriver.chrome.driver", propertyFile.getChromedriverpath());
        return new ChromeDriver();
    }

    @BeanScope
    @ConditionalOnProperty(name = "browser", havingValue = "firefox")
    public WebDriver firfoxeWebDriver() {
        System.setProperty("webdriver.gecko.driver", propertyFile.getFirefoxdriverpath());
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.setPageLoadStrategy(PageLoadStrategy.NORMAL);
        return new FirefoxDriver(firefoxOptions);
    }

    @BeanScope
    @ConditionalOnProperty(name = "browser", havingValue = "ie")
    public WebDriver ieWebDriver() {
        System.setProperty("webdriver.ie.driver", propertyFile.getIedriverpath());
        return new InternetExplorerDriver();
    }

    @BeanScope
    public WebDriverWait driverWait(WebDriver driver) {
        return new WebDriverWait(driver, propertyFile.getTimeout());
    }
}
