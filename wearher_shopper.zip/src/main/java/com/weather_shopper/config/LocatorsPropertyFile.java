package com.weather_shopper.config;

import com.weather_shopper.annotations.PageObjects;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;

@Data
@PageObjects
@PropertySource("classpath:locators.properties")
public class LocatorsPropertyFile {


    @Value("${currentTemperature_id}")
    private String currentTemperature_id;

    @Value("${buyMoisturizer_xpath}")
    private String buyMoisturizer_xpath;

    @Value("${buySunscreen_xpath}")
    private String buySunscreen_xpath;

    @Value("${productList_xpath}")
    private String productList_xpath;

    @Value("${addButton_xpath}")
    private String addButton_xpath;

    @Value("${cartButton_xpath}")
    private String cartButton_xpath;

    @Value("${payWithCardButton_xpath}")
    private String payWithCardButton_xpath;

    @Value("${emailText_id}")
    private String emailText_id;

    @Value("${cardNumberText_id}")
    private String cardNumberText_id;

    @Value("${expiryText_id}")
    private String expiryText_id;

    @Value("${cvcText_id}")
    private String cvcText_id;

    @Value("${zipCodeText_id}")
    private String zipCodeText_id;

    @Value("${payButton_id}")
    private String payButton_id;
}
