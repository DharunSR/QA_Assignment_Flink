package com.weather_shopper.StepDefinition;

import com.weather_shopper.annotations.LazyAutowired;
import com.weather_shopper.basePage.Base_Page;
import com.weather_shopper.config.LocatorsPropertyFile;
import com.weather_shopper.config.PropertyFile;
import com.weather_shopper.dataProvider.dataProvider;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.boot.test.context.SpringBootTest;

import java.lang.reflect.Array;
import java.util.List;
import java.util.Map;

@SpringBootTest
public class stepDefinition_weatherShopper {

    @LazyAutowired
    Base_Page basePage;

    @LazyAutowired
    PropertyFile propertyFile;

    @LazyAutowired
    LocatorsPropertyFile locatorsPropertyFile;

    @LazyAutowired
    com.weather_shopper.dataProvider.dataProvider dataProvider;

    @Given("browser is at the weather shopper application")
    public void launchApplication() {
        basePage.load_page(propertyFile.getUrl());
    }
    @Given("user checks for the current temperature to select the appropriate product")
    public void checkTemperature() {
        String temp = basePage.get_text(basePage.returnElement_id(locatorsPropertyFile.getCurrentTemperature_id()));
        String currTem [] = temp.split(" ");
        dataProvider.setCurrentTemperature(currTem[0]);
    }
    @When("user clicks buy on the product category")
    public void user_clicks_buy_on_the_product_category() {
        if (Integer.parseInt(dataProvider.getCurrentTemperature())<= 19){
            basePage.click_button(basePage.returnElement_xpath(locatorsPropertyFile.getBuyMoisturizer_xpath()));
            dataProvider.setProductCategory("moisturizer");
            System.out.println(dataProvider.getProductCategory() +" product category is selected");
        }else if (Integer.parseInt(dataProvider.getCurrentTemperature())>= 34){
            basePage.click_button(basePage.returnElement_xpath(locatorsPropertyFile.getBuySunscreen_xpath()));
            dataProvider.setProductCategory("sunscreen");
            System.out.println(dataProvider.getProductCategory() +" product category is selected");
        }else {
            throw new RuntimeException("Temperature is neither below 19 nor above 34");
        }
    }
    @When("user selects the lease expensive product based on the criteria")
    public void user_selects_the_lease_expensive_product_based_on_the_criteria(io.cucumber.datatable.DataTable dataTable) {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        String products;
        switch (dataProvider.getProductCategory()){
            case ("moisturizer"):
                products = rows.get(0).get("moisturizer");
                break;
            case ("sunscreen"):
                products = rows.get(0).get("sunscreen");
                break;
            default:
                throw new RuntimeException("Unexpected value: " + dataProvider.getProductCategory());
        }
        String [] listProducts = products.split(",");
        dataProvider.setProduct1(listProducts[0]);
        dataProvider.setProduct2(listProducts[1]);
        basePage.selectLeastExpensiveProduct(dataProvider.getProduct1(), dataProvider.getProduct2());
    }
    @When("user clicks on cart button")
    public void user_clicks_on_cart_button() {
        basePage.click_button(basePage.returnElement_xpath(locatorsPropertyFile.getCartButton_xpath()));
    }
    @When("user clicks on pay with card button")
    public void user_clicks_on_pay_with_card_button() {
        basePage.click_button(basePage.returnElement_xpath(locatorsPropertyFile.getPayWithCardButton_xpath()));
    }
    @When("user enters his details")
    public void user_enters_his_details(io.cucumber.datatable.DataTable dataTable) {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        dataProvider.setEmail(rows.get(0).get("email"));
        dataProvider.setCardnumber(rows.get(0).get("cardnumber"));
        dataProvider.setValidity(rows.get(0).get("validity"));
        dataProvider.setCvv(rows.get(0).get("cvv"));
        dataProvider.setPostcode(rows.get(0).get("postcode"));

//        basePage.returnFrames();
        basePage.click_button(basePage.returnElement_xpath(locatorsPropertyFile.getPayButton_id()));
        basePage.enter_text(basePage.returnElement_id(locatorsPropertyFile.getEmailText_id()), dataProvider.getEmail());
        basePage.enter_text(basePage.returnElement_id(locatorsPropertyFile.getCardNumberText_id()), dataProvider.getCardnumber());
        basePage.enter_text(basePage.returnElement_id(locatorsPropertyFile.getExpiryText_id()), dataProvider.getValidity());
        basePage.enter_text(basePage.returnElement_id(locatorsPropertyFile.getCvcText_id()), dataProvider.getCvv());
        basePage.enter_text(basePage.returnElement_id(locatorsPropertyFile.getZipCodeText_id()), dataProvider.getPostcode());

    }
    @When("user clicks on pay button")
    public void user_clicks_on_pay_button() {
        basePage.click_button(basePage.returnElement_xpath(locatorsPropertyFile.getPayButton_id()));
    }
    @Then("product purchased confirmation page displayed")
    public void product_purchased_confirmation_page_displayed() {
        System.out.println(dataProvider.getProductCategory()+" Purchased successfully");
    }
}
